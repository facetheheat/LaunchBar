# Open in Bugzilla: The clipboard link parser

This action - the clipboard links parser. If someone send you short ticket to bugzilla bugtracker, you can easily open it in a seconds. 


## Features
* parsing multiple ticket numbers

 
## Installation
* Click "Download ZIP" on the right
* Run LaunchBar/Open In Bugzilla.lbaction to install


![](./images/Bugzilla_Intro.png)
![](./images/Bugzilla_Demo.gif)


