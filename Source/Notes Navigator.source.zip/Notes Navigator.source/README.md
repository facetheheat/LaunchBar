# Notes Navigator

An action for navigating between notes & folder from Notas.app.
Hit 'Return' to open Notes.app with seleted note.

## Features
* Hit 'Enter' to open note
* Simple keyboard navigation
* Groups notes by folders


## Installation
* Click "Download ZIP" on the right
* Run LaunchBar/Note Navigator.lbaction to install

![](./images/Notes_Demo.gif)
