# Paths: copy a file path

This action copies file path(from Finder window) to the clipboard. 

## Features
* support multiple files selection
 
## Installation
* Click "Download ZIP" on the right
* Run LaunchBar/Paths.lbaction to install


![](./images/Paths_Intro.png)

