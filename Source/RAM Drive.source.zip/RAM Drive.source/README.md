# RAM Drive

This action creates a RAM drive with selected size and format volume with any installed filesystem.

![](images/RAMDrive_Intro.png)
![](images/RAMDrive.gif)

Notes:
* 

## Installation
* Click "Download ZIP" on the right
* Run LaunchBar/Ram Drive.lbaction to install
