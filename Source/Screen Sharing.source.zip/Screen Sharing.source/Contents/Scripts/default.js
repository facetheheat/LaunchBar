function runWithString(argument)
{
    LaunchBar.openURL('vnc://' + argument);
}