# VNC History: Screen Sharing.app history viewer with auto substitution

This action - the viewer of history of screen sharing connections.

## Features
* Input: smb, cifs, windows sharing, unix links
* Copy one or multiple links

 
## Installation
* Get connections from *.vncloc files
* Auto substitution


![](./images/ScreenSharing_Demo.gif)


