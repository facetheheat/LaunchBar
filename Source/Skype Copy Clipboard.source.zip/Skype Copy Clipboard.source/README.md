# Skype: Copy friend's name to the clipboard

This action helps to copy skype friend's name & account to the clipboard.
And you can easyly share it via email or other sharing channel.

## Features
* Autocomplete Suggestions

## Installation
* Click "Download ZIP" on the right
* Run LaunchBar/Skype Copy Clipboard.lbaction to install

## Screenshot
![](./images/Skype_CopyClipboard_Intro.png)

## Demo
![](./images/Skype_CopyClipboard_Demo.gif)


