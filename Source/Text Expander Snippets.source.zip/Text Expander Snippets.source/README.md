# Text Expander Snippets

## Demo
![](./Images/text_expander_snippets.gif)

## By the way
I know about 'Suggest Matching Abbreviations' shortcut in Text Expander preferences, but I want to get integration with LaunchBar.
![](./Images/te_preferences.png)
![](./Images/te_native_window.png)




